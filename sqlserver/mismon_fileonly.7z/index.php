<?php include "connection/connectsql.php"; ?>
<?php include "template/header.php"; ?>
<?php include "template/sidebar.php"; ?>
<!-- include "vw_index.php" -->

<?php
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
switch($page){
    case "dashboard_current":
        include "vw_dashboard_current.php";
        break;
    case "dashboard_new":
        include "vw_dashboard_new.php";
        break;        
    case "employee":
        include "vw_employee.php";
        break;
    case "storage":
        include "vw_storage.php";
        break;
    default:
        include "vw_dashboard_current.php";
        break;
}
?>
<?php include "template/footer.php"; ?>