<?php
// $conninfoServer = isset($_POST['conninfoServer']) ? $_POST['conninfoServer'] : '';
// $connServerName = isset($_POST['connServerName']) ? $_POST['connServerName'] : '';
$Svr  = isset($_GET['Svr']) ? $_GET['Svr'] : '';
$Db   = isset($_GET['Db']) ? $_GET['Db'] : '';

if(empty($Svr) and empty($Db)){
  header("location:?page=vw_storage");
}else{
    $conninfoServer = array("Database"=>"$Db", "UID"=>"", "PWD"=>"");
    $connServerName = sqlsrv_connect($Svr, $conninfoServer);

    $query = "
    SELECT      SCHEMA_NAME(A.schema_id) + '.' +
        --A.Name, SUM(B.rows) AS 'RowCount'  Use AVG instead of SUM
          A.Name TableName, AVG(B.rows) AS 'RowCount'
FROM        sys.objects A
INNER JOIN sys.partitions B ON A.object_id = B.object_id
WHERE       A.type = 'U'
GROUP BY    A.schema_id, A.Name
    ";  
}

?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Data Row Count Table</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><span id="date_time"></span><script type="text/javascript">window.onload = date_time('date_time');</script></li>
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li> -->
            </ol>
          </div>
          <!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
    <div class="col-sm-1">
    <button type="button" class="btn btn-block btn-primary" onclick="window.history.back();">Back</button>
          </div>
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-12">
            <div class="card card-info">
                <!-- <div class="card-header">
                  <h3 class="card-title">Input Server Name</h3>
                </div> -->
                <!-- /.card-header -->
                <!-- form start -->
                <!-- <form class="form-horizontal" action="?page=datatable" method="POST">
                  <div class="card-body">
                    <div class="form-group row">
                      <label for="ServerName" class="col-sm-2 col-form-label">Server Name</label>
                      <div class="col-sm-9">
                        <input type="ServerName" name="ServerName" class="form-control" id="ServerName" placeholder="Server Name">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="ServerName" class="col-sm-2 col-form-label">Database Name</label>
                      <div class="col-sm-9">
                        <input type="DatabaseName" name="DatabaseName" class="form-control" id="DatabaseName" placeholder="Database Name">
                      </div>
                    </div>                   
                  </div>
                  <div class="card-footer">
                    <button type="submit" name="submit" class="btn btn-info">Check</button>
                  </div> -->
                  <!-- /.card-body -->

                </form>
            </div>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><b>DataTable For Server <?php echo $Svr ?> | Database <?= $Db ?></b></h3>
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Table Name</th>
                    <th>RowCount</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                  <?php 
                      if(!empty($Svr)){
                      $stmt = sqlsrv_query($connServerName, $query); 
                      $no = 1;
                      while($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))
                      {
                      ?>                          
                    <td><?php echo $no ?></td>
                    <td><?php echo $row['TableName']; ?></td>
                    <td><?php echo $row['RowCount']; ?></td>
                  </tr>
                  <?php $no++; } } ?>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
        </div>
        <!-- /.row -->

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->