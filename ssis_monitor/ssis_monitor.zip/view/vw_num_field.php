<?php  
/* Connect to the local server using Windows Authentication and   
specify the AdventureWorks database as the database in use. */  
$serverName = "sofbi03";  
$connectionInfo = array( "Database"=>"master");  
$conn = sqlsrv_connect( $serverName, $connectionInfo);  
if( $conn === false )  
{  
     echo "Could not connect.\n";  
     die( print_r( sqlsrv_errors(), true));  
}  
  
/* Define and execute the query. */  
$tsql = "with fs
as
(
    select database_id, type, size * 8.0 / 1024 size, physical_name
    from sys.master_files
)
select 
    name, 
    (select sum(size) from fs where type = 0 and fs.database_id = db.database_id) DataFileSizeMB,
    (select sum(size) from fs where type = 1 and fs.database_id = db.database_id) LogFileSizeMB,
  (select sum(size) from fs where type = 0 and fs.database_id = db.database_id) + 
  (select sum(size) from fs where type = 1 and fs.database_id = db.database_id) TotalSize,
  (select top 1 physical_name from fs where fs.database_id = db.database_id) physical_name,
  compatibility_level, recovery_model_desc, suser_sname(owner_sid) db_owner
from sys.databases db";  
$stmt = sqlsrv_query($conn, $tsql);  
if( $stmt === false)  
{  
     echo "Error in executing query.\n";  
     die( print_r( sqlsrv_errors(), true));  
}  
  
/* Retrieve the number of fields. */  
$numFields = sqlsrv_num_fields( $stmt );  

/* Get and display field metadata. */
echo '<table id="example1" class="table table-bordered table-striped" border="1"><thead><tr>';
foreach(sqlsrv_field_metadata($stmt) as $field){
    echo '<th>'.$field['Name'].'</th>'; // The Name key provides the column name
}
echo '<th>Action<th>';
echo '</tr></thead><tbody><tr>';

/* Iterate through each row of the result set. */  
while( sqlsrv_fetch( $stmt ))  
{  
    
     /* Iterate through the fields of each row. */  
     for($i = 0; $i < $numFields; $i++)  
     {  
        echo '<td>'.sqlsrv_get_field($stmt, $i, SQLSRV_PHPTYPE_STRING(SQLSRV_ENC_CHAR)).'</td>';
        //   echo sqlsrv_get_field($stmt, $i, SQLSRV_PHPTYPE_STRING(SQLSRV_ENC_CHAR))." ";  
     }  
     echo '<td>
     <a class="dropdown-item" href="?page=datatable&ServerName=Svr&DatabaseName=Db">Check Row Count</a>
     </td>';
     echo '</tr>';
     
}  
echo '</tfoot></table>';    
  
/* Free statement and connection resources. */  
sqlsrv_free_stmt( $stmt );  
sqlsrv_close( $conn );  
?>  