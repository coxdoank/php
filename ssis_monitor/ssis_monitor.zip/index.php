<?php include "connection/connectsql.php"; ?>
<?php include "layout/header.php"; ?>
<?php include "layout/sidebar.php"; ?>
<!-- include "vw_index.php" -->

<?php
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
switch($page){
    case "dashboard_current":
        include "view/vw_dashboard_current.php";
        break;
    case "dashboard_new":
        include "view/vw_dashboard_new.php";
        break;        
    case "employee":
        include "view/vw_employee.php";
        break;
    case "storage":
        include "view/vw_storage.php";
        break;
    case "datatable":
        include "view/vw_datatable.php";
        break;
    default:
        include "view/vw_dashboard_current.php";
        break;
}
?>
<?php include "layout/footer.php"; ?>